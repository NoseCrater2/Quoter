<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\Variant;
use Faker\Generator as Faker;

$factory->define(Variant::class, function (Faker $faker) {
    return [
        //
    ];
});
