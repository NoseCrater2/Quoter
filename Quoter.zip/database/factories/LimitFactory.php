<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\Limit;
use Faker\Generator as Faker;

$factory->define(Limit::class, function (Faker $faker) {
    return [
        //
    ];
});
