<!DOCTYPE html>
<html class="has-aside-left has-aside-expanded">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Cotizador</title>
    <script src="<?php echo e(asset('js/app.js')); ?>" defer></script>
    <link href="<?php echo e(asset('/css/app.css')); ?>" rel="stylesheet" />
</head>

<body>
    <div id="app">
      <login></login>
    </div>
    
</body>

</html>
<?php /**PATH C:\Users\angel\Documents\Quoter\resources\views/login.blade.php ENDPATH**/ ?>