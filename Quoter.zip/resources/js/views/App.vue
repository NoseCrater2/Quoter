<template>
   <div>
    <section class="section">
      <main>
        <router-view></router-view>
      </main>
    </section>
  </div>
</template>

<script>
export default {};
</script>

