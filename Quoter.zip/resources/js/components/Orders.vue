<template>
    <div>
        <h1>ORDENES</h1>
    </div>
</template>

<script>
export default {
    
}
</script>