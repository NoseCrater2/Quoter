import Vue from 'vue'
import Vuetify from 'vuetify'
import 'vuetify/dist/vuetify.min.css'
import "@mdi/font/css/materialdesignicons.css"
//import es from "../../node_modules/vuetify/src/locale/es.ts"

Vue.use(Vuetify)

const opts = {
    iconfont: "mdi",
  
}

export default new Vuetify(opts)