(window["webpackJsonp"] = window["webpackJsonp"] || []).push([[2],{

/***/ "./node_modules/babel-loader/lib/index.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/views/Index/Home2.vue?vue&type=script&lang=js&":
/*!*****************************************************************************************************************************************************************!*\
  !*** ./node_modules/babel-loader/lib??ref--4-0!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/views/Index/Home2.vue?vue&type=script&lang=js& ***!
  \*****************************************************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
/* harmony default export */ __webpack_exports__["default"] = ({
  data: function data() {
    return {
      showProducts: true,
      showSearch: false,
      drawer: false,
      dialog: false,
      isMobile: false,
      icons: [{
        image: 'img/cortinas.png',
        width: 150,
        mobilew: 75
      }, {
        image: 'img/toldos.png',
        width: 200,
        mobilew: 100
      }],
      offsetTop: 0,
      persianas: [{
        src: 'https://cdn.vuetifyjs.com/images/carousel/squirrel.jpg'
      }, {
        src: 'https://cdn.vuetifyjs.com/images/carousel/sky.jpg'
      }, {
        src: 'https://cdn.vuetifyjs.com/images/carousel/bird.jpg'
      }, {
        src: 'https://cdn.vuetifyjs.com/images/carousel/planet.jpg'
      }],
      items: [{
        title: 'CORTINAS',
        subtext: 'Contamos con una extensa línea de cortinas para la decoración de tu hogar u oficina',
        img: 'https://images.unsplash.com/photo-1498038432885-c6f3f1b912ee?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=2100&q=80'
      }, {
        title: 'TOLDOS',
        subtext: 'Contamos con una gran varidad de diseños para que se adapten a tus necesidades',
        img: 'https://cdn.vuetifyjs.com/images/carousel/sky.jpg'
      }],
      transparent: 'rgba(255, 255, 255, 0)'
    };
  },
  mounted: function mounted() {
    this.onResize();
    window.addEventListener('resize', this.onResize, {
      passive: true
    });
  },
  computed: {},
  methods: {
    onResize: function onResize() {
      this.isMobile = window.innerWidth < 780;
    }
  }
});

/***/ }),

/***/ "./node_modules/css-loader/index.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/views/Index/Home2.vue?vue&type=style&index=0&lang=css&":
/*!************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/css-loader??ref--6-1!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src??ref--6-2!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/views/Index/Home2.vue?vue&type=style&index=0&lang=css& ***!
  \************************************************************************************************************************************************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

exports = module.exports = __webpack_require__(/*! ../../../../node_modules/css-loader/lib/css-base.js */ "./node_modules/css-loader/lib/css-base.js")(false);
// imports


// module
exports.push([module.i, "\n*{\r\n    font-family: 'Raleway';\n}\n.v-window__next, .v-window__prev {    \r\n\tmargin: 0 115px !important;\r\n\tbackground: none !important;\n}\n.v-window__next > button > span > i{\r\n  font-size: 100px !important;\n}\n.v-window__prev > button > span > i{\r\n  font-size: 100px !important;\n}\n.on-hover {\r\n    \r\n    transform: scale(1.02);\r\n    -moz-transform: scale(1.02);\r\n    -webkit-transform: scale(1.02);\r\n    -o-transform: scale(1.02);\r\n    -ms-transform: scale(1.02);\r\n    transition-duration: 1s;\n}\n.condensed{\r\n   font-stretch: ultra-expanded;\r\n     font-weight: normal !important;\r\n      transition-duration: 1.5s;\r\n      font-weight: bolder !important;\n}\n.reset {\r\n    transition-duration: 1s;\n}\n.marco{\r\n    border: 4px solid white;\n}\n.force-center{\r\n    flex-grow: 0 !important;\n}\r\n", ""]);

// exports


/***/ }),

/***/ "./node_modules/style-loader/index.js!./node_modules/css-loader/index.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/views/Index/Home2.vue?vue&type=style&index=0&lang=css&":
/*!****************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/style-loader!./node_modules/css-loader??ref--6-1!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src??ref--6-2!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/views/Index/Home2.vue?vue&type=style&index=0&lang=css& ***!
  \****************************************************************************************************************************************************************************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {


var content = __webpack_require__(/*! !../../../../node_modules/css-loader??ref--6-1!../../../../node_modules/vue-loader/lib/loaders/stylePostLoader.js!../../../../node_modules/postcss-loader/src??ref--6-2!../../../../node_modules/vue-loader/lib??vue-loader-options!./Home2.vue?vue&type=style&index=0&lang=css& */ "./node_modules/css-loader/index.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/views/Index/Home2.vue?vue&type=style&index=0&lang=css&");

if(typeof content === 'string') content = [[module.i, content, '']];

var transform;
var insertInto;



var options = {"hmr":true}

options.transform = transform
options.insertInto = undefined;

var update = __webpack_require__(/*! ../../../../node_modules/style-loader/lib/addStyles.js */ "./node_modules/style-loader/lib/addStyles.js")(content, options);

if(content.locals) module.exports = content.locals;

if(false) {}

/***/ }),

/***/ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/views/Index/Home2.vue?vue&type=template&id=519fa447&":
/*!*********************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/views/Index/Home2.vue?vue&type=template&id=519fa447& ***!
  \*********************************************************************************************************************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "render", function() { return render; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return staticRenderFns; });
var render = function() {
  var _vm = this
  var _h = _vm.$createElement
  var _c = _vm._self._c || _h
  return _c(
    "div",
    { attrs: { id: "app" } },
    [
      _c(
        "v-carousel",
        {
          attrs: {
            "hide-delimiters": !_vm.isMobile,
            "show-arrows": !_vm.isMobile
          }
        },
        _vm._l(_vm.persianas, function(item, i) {
          return _c(
            "v-carousel-item",
            { key: i },
            [
              _c(
                "v-parallax",
                { attrs: { src: item.src } },
                [
                  _c(
                    "v-row",
                    {
                      staticStyle: { "margin-top": "100px" },
                      attrs: { align: "center", justify: "center" }
                    },
                    [
                      _c(
                        "div",
                        {
                          staticClass: "text-center",
                          staticStyle: {
                            "background-color": "rgba(10, 10, 10, 0.5)"
                          }
                        },
                        [
                          _c(
                            "p",
                            {
                              staticClass: " on-hover ma-5",
                              class: _vm.isMobile ? "text-h5" : "text-h3"
                            },
                            [
                              _vm._v(
                                "\n                            PERSIANAS ENROLLABLES\n                        "
                              )
                            ]
                          ),
                          _vm._v(" "),
                          _c("p", { staticClass: "subheading" }, [
                            _vm._v(
                              "\n                        La más amplia gama de texturas y colores del Mercado Nacional\n                        "
                            )
                          ])
                        ]
                      )
                    ]
                  ),
                  _vm._v(" "),
                  _c(
                    "v-row",
                    {
                      staticStyle: { "margin-bottom": "100px" },
                      attrs: { justify: "center", align: "start" }
                    },
                    [
                      _c(
                        "div",
                        [
                          _c(
                            "v-btn",
                            { attrs: { color: "transparent", depressed: "" } },
                            [
                              _c(
                                "v-icon",
                                { attrs: { size: "35", left: "" } },
                                [_vm._v("mdi-plus-circle-outline")]
                              ),
                              _vm._v("Ver más\n                        ")
                            ],
                            1
                          )
                        ],
                        1
                      )
                    ]
                  )
                ],
                1
              )
            ],
            1
          )
        }),
        1
      ),
      _vm._v(" "),
      _c(
        "v-row",
        { staticClass: "ma-4", attrs: { justify: "space-around" } },
        _vm._l(_vm.items, function(item, i) {
          return _c(
            "v-col",
            { key: i, attrs: { cols: "12", md: "6" } },
            [
              _c("v-hover", {
                scopedSlots: _vm._u(
                  [
                    {
                      key: "default",
                      fn: function(ref) {
                        var hover = ref.hover
                        return [
                          _c(
                            "v-card",
                            {
                              attrs: {
                                elevation: hover ? 2 : 6,
                                height: "250px"
                              }
                            },
                            [
                              _c(
                                "v-img",
                                {
                                  staticClass:
                                    "transparent--text  text-left align-center reset",
                                  class: { "on-hover ": hover },
                                  attrs: {
                                    src: item.img,
                                    gradient: hover
                                      ? "rgba(71, 165, 173, 0.5) 100%, transparent 72px"
                                      : "",
                                    height: "250px"
                                  }
                                },
                                [
                                  _c(
                                    "v-row",
                                    {
                                      staticClass: "mx-8",
                                      class: { "marco white--text": hover },
                                      staticStyle: {
                                        "flex-wrap": "nowrap",
                                        padding: "-40px 40px"
                                      },
                                      attrs: { "no-gutters": "" }
                                    },
                                    [
                                      _c(
                                        "v-col",
                                        {
                                          staticClass:
                                            "flex-grow-0 flex-shrink-0 force-center mt-4",
                                          attrs: {
                                            cols: "4",
                                            "align-self": "center"
                                          }
                                        },
                                        [
                                          _c("v-img", {
                                            class: { "on-hover": hover },
                                            attrs: {
                                              width: _vm.isMobile
                                                ? _vm.icons[i].mobilew
                                                : _vm.icons[i].width,
                                              color: "transparent",
                                              src: hover
                                                ? _vm.icons[i].image
                                                : null
                                            }
                                          })
                                        ],
                                        1
                                      ),
                                      _vm._v(" "),
                                      _c(
                                        "v-col",
                                        {
                                          staticClass:
                                            " flex-grow-0 flex-shrink-1 reset mt-4",
                                          attrs: { cols: "7" }
                                        },
                                        [
                                          _c(
                                            "div",
                                            {
                                              class: _vm.isMobile
                                                ? "text-h4"
                                                : "text-h3"
                                            },
                                            [
                                              _c(
                                                "p",
                                                {
                                                  class: { condensed: hover },
                                                  staticStyle: {
                                                    "letter-spacing": "0.125em"
                                                  }
                                                },
                                                [
                                                  _vm._v(
                                                    "\n                                        " +
                                                      _vm._s(item.title) +
                                                      "\n                                    "
                                                  )
                                                ]
                                              )
                                            ]
                                          ),
                                          _vm._v(" "),
                                          _c("div", [
                                            _c(
                                              "p",
                                              {
                                                staticClass:
                                                  "text-h6  text-justify reset ",
                                                staticStyle: {
                                                  "line-height": "1em"
                                                },
                                                attrs: { color: "transparent" }
                                              },
                                              [
                                                _vm._v(
                                                  "\n                                        " +
                                                    _vm._s(item.subtext) +
                                                    "\n                                    "
                                                )
                                              ]
                                            )
                                          ])
                                        ]
                                      )
                                    ],
                                    1
                                  )
                                ],
                                1
                              )
                            ],
                            1
                          )
                        ]
                      }
                    }
                  ],
                  null,
                  true
                )
              })
            ],
            1
          )
        }),
        1
      ),
      _vm._v(" "),
      _c(
        "v-row",
        {
          staticClass: "grey lighten-3 ",
          attrs: { height: "350", align: "center", justify: "center" }
        },
        [
          _c(
            "v-col",
            {
              staticClass: "text-center",
              attrs: { cols: "12", md: "3", sm: "6" }
            },
            [
              _c(
                "p",
                {
                  staticClass: " mb-n3 mt-6",
                  staticStyle: { "font-size": "25px" }
                },
                [
                  _vm._v(
                    "\n                Para nosotros las persianas no son solo un elemento decorativo en tu ventana,\n            "
                  )
                ]
              ),
              _vm._v(" "),
              _c("p", { staticStyle: { "font-size": "30px" } }, [
                _vm._v("\n                las  "),
                _c("b", [_vm._v("Persianas de Rollux")]),
                _vm._v(
                  " crean ambientes, emociones y sensaciones.\n            "
                )
              ]),
              _vm._v(" "),
              _c(
                "v-btn",
                {
                  staticClass: "grey lighten-3 mb-6",
                  attrs: { depressed: "" }
                },
                [
                  _c(
                    "v-icon",
                    { staticClass: "mr-4", attrs: { size: "35", left: "" } },
                    [_vm._v("mdi-plus-circle-outline")]
                  ),
                  _vm._v("Conocer más\n            ")
                ],
                1
              )
            ],
            1
          )
        ],
        1
      )
    ],
    1
  )
}
var staticRenderFns = []
render._withStripped = true



/***/ }),

/***/ "./resources/js/views/Index/Home2.vue":
/*!********************************************!*\
  !*** ./resources/js/views/Index/Home2.vue ***!
  \********************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _Home2_vue_vue_type_template_id_519fa447___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./Home2.vue?vue&type=template&id=519fa447& */ "./resources/js/views/Index/Home2.vue?vue&type=template&id=519fa447&");
/* harmony import */ var _Home2_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./Home2.vue?vue&type=script&lang=js& */ "./resources/js/views/Index/Home2.vue?vue&type=script&lang=js&");
/* empty/unused harmony star reexport *//* harmony import */ var _Home2_vue_vue_type_style_index_0_lang_css___WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./Home2.vue?vue&type=style&index=0&lang=css& */ "./resources/js/views/Index/Home2.vue?vue&type=style&index=0&lang=css&");
/* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");






/* normalize component */

var component = Object(_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_3__["default"])(
  _Home2_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__["default"],
  _Home2_vue_vue_type_template_id_519fa447___WEBPACK_IMPORTED_MODULE_0__["render"],
  _Home2_vue_vue_type_template_id_519fa447___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"],
  false,
  null,
  null,
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "resources/js/views/Index/Home2.vue"
/* harmony default export */ __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ "./resources/js/views/Index/Home2.vue?vue&type=script&lang=js&":
/*!*********************************************************************!*\
  !*** ./resources/js/views/Index/Home2.vue?vue&type=script&lang=js& ***!
  \*********************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_babel_loader_lib_index_js_ref_4_0_node_modules_vue_loader_lib_index_js_vue_loader_options_Home2_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../node_modules/babel-loader/lib??ref--4-0!../../../../node_modules/vue-loader/lib??vue-loader-options!./Home2.vue?vue&type=script&lang=js& */ "./node_modules/babel-loader/lib/index.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/views/Index/Home2.vue?vue&type=script&lang=js&");
/* empty/unused harmony star reexport */ /* harmony default export */ __webpack_exports__["default"] = (_node_modules_babel_loader_lib_index_js_ref_4_0_node_modules_vue_loader_lib_index_js_vue_loader_options_Home2_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./resources/js/views/Index/Home2.vue?vue&type=style&index=0&lang=css&":
/*!*****************************************************************************!*\
  !*** ./resources/js/views/Index/Home2.vue?vue&type=style&index=0&lang=css& ***!
  \*****************************************************************************/
/*! no static exports found */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_style_loader_index_js_node_modules_css_loader_index_js_ref_6_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_6_2_node_modules_vue_loader_lib_index_js_vue_loader_options_Home2_vue_vue_type_style_index_0_lang_css___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../node_modules/style-loader!../../../../node_modules/css-loader??ref--6-1!../../../../node_modules/vue-loader/lib/loaders/stylePostLoader.js!../../../../node_modules/postcss-loader/src??ref--6-2!../../../../node_modules/vue-loader/lib??vue-loader-options!./Home2.vue?vue&type=style&index=0&lang=css& */ "./node_modules/style-loader/index.js!./node_modules/css-loader/index.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/views/Index/Home2.vue?vue&type=style&index=0&lang=css&");
/* harmony import */ var _node_modules_style_loader_index_js_node_modules_css_loader_index_js_ref_6_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_6_2_node_modules_vue_loader_lib_index_js_vue_loader_options_Home2_vue_vue_type_style_index_0_lang_css___WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_style_loader_index_js_node_modules_css_loader_index_js_ref_6_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_6_2_node_modules_vue_loader_lib_index_js_vue_loader_options_Home2_vue_vue_type_style_index_0_lang_css___WEBPACK_IMPORTED_MODULE_0__);
/* harmony reexport (unknown) */ for(var __WEBPACK_IMPORT_KEY__ in _node_modules_style_loader_index_js_node_modules_css_loader_index_js_ref_6_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_6_2_node_modules_vue_loader_lib_index_js_vue_loader_options_Home2_vue_vue_type_style_index_0_lang_css___WEBPACK_IMPORTED_MODULE_0__) if(["default"].indexOf(__WEBPACK_IMPORT_KEY__) < 0) (function(key) { __webpack_require__.d(__webpack_exports__, key, function() { return _node_modules_style_loader_index_js_node_modules_css_loader_index_js_ref_6_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_6_2_node_modules_vue_loader_lib_index_js_vue_loader_options_Home2_vue_vue_type_style_index_0_lang_css___WEBPACK_IMPORTED_MODULE_0__[key]; }) }(__WEBPACK_IMPORT_KEY__));
 /* harmony default export */ __webpack_exports__["default"] = (_node_modules_style_loader_index_js_node_modules_css_loader_index_js_ref_6_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_6_2_node_modules_vue_loader_lib_index_js_vue_loader_options_Home2_vue_vue_type_style_index_0_lang_css___WEBPACK_IMPORTED_MODULE_0___default.a); 

/***/ }),

/***/ "./resources/js/views/Index/Home2.vue?vue&type=template&id=519fa447&":
/*!***************************************************************************!*\
  !*** ./resources/js/views/Index/Home2.vue?vue&type=template&id=519fa447& ***!
  \***************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_Home2_vue_vue_type_template_id_519fa447___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!../../../../node_modules/vue-loader/lib??vue-loader-options!./Home2.vue?vue&type=template&id=519fa447& */ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/views/Index/Home2.vue?vue&type=template&id=519fa447&");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "render", function() { return _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_Home2_vue_vue_type_template_id_519fa447___WEBPACK_IMPORTED_MODULE_0__["render"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_Home2_vue_vue_type_template_id_519fa447___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"]; });



/***/ })

}]);