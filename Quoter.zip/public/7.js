(window["webpackJsonp"] = window["webpackJsonp"] || []).push([[7],{

/***/ "./node_modules/babel-loader/lib/index.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/views/Index/Curtains.vue?vue&type=script&lang=js&":
/*!********************************************************************************************************************************************************************!*\
  !*** ./node_modules/babel-loader/lib??ref--4-0!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/views/Index/Curtains.vue?vue&type=script&lang=js& ***!
  \********************************************************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _components_Products__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../../components/Products */ "./resources/js/components/Products.vue");
//
//
//
//
//
//
//
//
//
//

/* harmony default export */ __webpack_exports__["default"] = ({
  data: function data() {
    return {
      curtains: [{
        id: 1,
        name: 'Uno',
        price: 100.00,
        image: 'https://i.pinimg.com/originals/ca/9d/f5/ca9df54ce60dcfc898a87f77cec0e7b7.jpg'
      }, {
        id: 2,
        name: 'Dos',
        price: 100.00,
        image: 'https://www.creativeswall.com/wp-content/uploads/2014/04/fabric_texture_04_preview.jpg'
      }, {
        id: 3,
        name: 'Tres',
        price: 100.00,
        image: 'https://cdn02.plentymarkets.com/2brofzsczyt8/item/images/179823/full/Tapete-Vlies-Strukturiert-kupfer-Metallic-Rasch-Te.jpg'
      }, {
        id: 4,
        name: 'Cuatro',
        price: 100.00,
        image: 'https://i.pinimg.com/originals/4b/63/01/4b6301946bd5495ff9c200fc4308a543.jpg'
      }, {
        id: 5,
        name: 'Cinco',
        price: 100.00,
        image: 'https://images-na.ssl-images-amazon.com/images/I/914IWKpapWL._AC_SL1500_.jpg'
      }, {
        id: 6,
        name: 'Seis',
        price: 100.00,
        image: 'https://www.wallpaperwarehouse.com/upload_media/product/preview/1554317253BIORTEFJ_1554414773.jpg'
      }, {
        id: 7,
        name: 'Siete',
        price: 100.00,
        image: 'https://bhf-cdn.azureedge.net/bhf-blob-prod/0034928_arya-brown-fabric-texture-wallpaper_600.jpeg'
      }, {
        id: 8,
        name: 'Ocho',
        price: 100.00,
        image: ''
      }, {
        id: 9,
        name: 'Nueve',
        price: 100.00,
        image: ''
      }, {
        id: 10,
        name: 'Dies',
        price: 100.00,
        image: ''
      }, {
        id: 11,
        name: 'Once',
        price: 100.00,
        image: ''
      }, {
        id: 12,
        name: 'Doce',
        price: 100.00,
        image: ''
      }, {
        id: 13,
        name: 'Trece',
        price: 100.00,
        image: ''
      }]
    };
  },
  components: {
    'products': _components_Products__WEBPACK_IMPORTED_MODULE_0__["default"]
  }
});

/***/ }),

/***/ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/views/Index/Curtains.vue?vue&type=template&id=badeee86&":
/*!************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/views/Index/Curtains.vue?vue&type=template&id=badeee86& ***!
  \************************************************************************************************************************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "render", function() { return render; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return staticRenderFns; });
var render = function() {
  var _vm = this
  var _h = _vm.$createElement
  var _c = _vm._self._c || _h
  return _c(
    "div",
    { attrs: { id: "app" } },
    [_c("products", { attrs: { products: _vm.curtains } })],
    1
  )
}
var staticRenderFns = []
render._withStripped = true



/***/ }),

/***/ "./resources/js/views/Index/Curtains.vue":
/*!***********************************************!*\
  !*** ./resources/js/views/Index/Curtains.vue ***!
  \***********************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _Curtains_vue_vue_type_template_id_badeee86___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./Curtains.vue?vue&type=template&id=badeee86& */ "./resources/js/views/Index/Curtains.vue?vue&type=template&id=badeee86&");
/* harmony import */ var _Curtains_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./Curtains.vue?vue&type=script&lang=js& */ "./resources/js/views/Index/Curtains.vue?vue&type=script&lang=js&");
/* empty/unused harmony star reexport *//* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");





/* normalize component */

var component = Object(_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__["default"])(
  _Curtains_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__["default"],
  _Curtains_vue_vue_type_template_id_badeee86___WEBPACK_IMPORTED_MODULE_0__["render"],
  _Curtains_vue_vue_type_template_id_badeee86___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"],
  false,
  null,
  null,
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "resources/js/views/Index/Curtains.vue"
/* harmony default export */ __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ "./resources/js/views/Index/Curtains.vue?vue&type=script&lang=js&":
/*!************************************************************************!*\
  !*** ./resources/js/views/Index/Curtains.vue?vue&type=script&lang=js& ***!
  \************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_babel_loader_lib_index_js_ref_4_0_node_modules_vue_loader_lib_index_js_vue_loader_options_Curtains_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../node_modules/babel-loader/lib??ref--4-0!../../../../node_modules/vue-loader/lib??vue-loader-options!./Curtains.vue?vue&type=script&lang=js& */ "./node_modules/babel-loader/lib/index.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/views/Index/Curtains.vue?vue&type=script&lang=js&");
/* empty/unused harmony star reexport */ /* harmony default export */ __webpack_exports__["default"] = (_node_modules_babel_loader_lib_index_js_ref_4_0_node_modules_vue_loader_lib_index_js_vue_loader_options_Curtains_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./resources/js/views/Index/Curtains.vue?vue&type=template&id=badeee86&":
/*!******************************************************************************!*\
  !*** ./resources/js/views/Index/Curtains.vue?vue&type=template&id=badeee86& ***!
  \******************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_Curtains_vue_vue_type_template_id_badeee86___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!../../../../node_modules/vue-loader/lib??vue-loader-options!./Curtains.vue?vue&type=template&id=badeee86& */ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/views/Index/Curtains.vue?vue&type=template&id=badeee86&");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "render", function() { return _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_Curtains_vue_vue_type_template_id_badeee86___WEBPACK_IMPORTED_MODULE_0__["render"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_Curtains_vue_vue_type_template_id_badeee86___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"]; });



/***/ })

}]);