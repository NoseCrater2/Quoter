(window["webpackJsonp"] = window["webpackJsonp"] || []).push([[0],{

/***/ "./node_modules/babel-loader/lib/index.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/components/Products.vue?vue&type=script&lang=js&":
/*!*******************************************************************************************************************************************************************!*\
  !*** ./node_modules/babel-loader/lib??ref--4-0!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/components/Products.vue?vue&type=script&lang=js& ***!
  \*******************************************************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var vue_h_zoom__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! vue-h-zoom */ "./node_modules/vue-h-zoom/dist/vue-h-zoom.js");
/* harmony import */ var vue_h_zoom__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(vue_h_zoom__WEBPACK_IMPORTED_MODULE_0__);
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//

/* harmony default export */ __webpack_exports__["default"] = ({
  data: function data() {
    return {
      productName: null,
      productId: 0,
      selectedIndex: 1,
      isMobile: false,
      dialog: false,
      model: null,
      search: '',
      filter: {},
      sortDesc: false,
      page: 1,
      itemsPerPage: 4,
      sortBy: 'price',
      keys: ['name', 'price', 'created_date']
    };
  },
  mounted: function mounted() {
    this.onResize();
    window.addEventListener('resize', this.onResize, {
      passive: true
    });
    this.productName = this.$route.params.name;
    this.productId = this.$route.params.id;
  },
  props: {
    value: null,
    products: {
      type: Array,
      required: true
    }
  },
  computed: {
    numberOfPages: function numberOfPages() {
      return Math.ceil(this.products.length / this.itemsPerPage);
    },
    filteredKeys: function filteredKeys() {
      return this.keys.filter(function (key) {
        return key !== 'name';
      });
    }
  },
  methods: {
    nextPage: function nextPage() {
      if (this.page + 1 <= this.numberOfPages) this.page += 1;
    },
    formerPage: function formerPage() {
      if (this.page - 1 >= 1) this.page -= 1;
    },
    updateItemsPerPage: function updateItemsPerPage(number) {
      this.itemsPerPage = number;
    },
    onResize: function onResize() {
      this.isMobile = window.innerWidth < 767;
    },
    openDialog: function openDialog(id) {
      this.selectedIndex = id;
      this.dialog = true;
    }
  },
  components: {
    VueHZoom: vue_h_zoom__WEBPACK_IMPORTED_MODULE_0___default.a
  }
});

/***/ }),

/***/ "./node_modules/css-loader/index.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/components/Products.vue?vue&type=style&index=0&lang=css&":
/*!**************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/css-loader??ref--6-1!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src??ref--6-2!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/components/Products.vue?vue&type=style&index=0&lang=css& ***!
  \**************************************************************************************************************************************************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

exports = module.exports = __webpack_require__(/*! ../../../node_modules/css-loader/lib/css-base.js */ "./node_modules/css-loader/lib/css-base.js")(false);
// imports


// module
exports.push([module.i, "\n.v-card--reveal {\r\nalign-items: center;\r\nbottom: 0;\r\njustify-content: center;\r\nposition: absolute;\r\nwidth: 100%;\n}\n.title{\r\n  background-color: #47a5ad; padding: 5px; font-size: 1rem; word-break: break-word !important;\n}\n.escalada{\r\n   transform: scale(1.02);\r\n    -moz-transform: scale(1.02);\r\n    -webkit-transform: scale(1.02);\r\n    -o-transform: scale(1.02);\r\n    -ms-transform: scale(1.02);\r\n    transition-duration: 0.5s;\n}\r\n\r\n", ""]);

// exports


/***/ }),

/***/ "./node_modules/style-loader/index.js!./node_modules/css-loader/index.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/components/Products.vue?vue&type=style&index=0&lang=css&":
/*!******************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/style-loader!./node_modules/css-loader??ref--6-1!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src??ref--6-2!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/components/Products.vue?vue&type=style&index=0&lang=css& ***!
  \******************************************************************************************************************************************************************************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {


var content = __webpack_require__(/*! !../../../node_modules/css-loader??ref--6-1!../../../node_modules/vue-loader/lib/loaders/stylePostLoader.js!../../../node_modules/postcss-loader/src??ref--6-2!../../../node_modules/vue-loader/lib??vue-loader-options!./Products.vue?vue&type=style&index=0&lang=css& */ "./node_modules/css-loader/index.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/components/Products.vue?vue&type=style&index=0&lang=css&");

if(typeof content === 'string') content = [[module.i, content, '']];

var transform;
var insertInto;



var options = {"hmr":true}

options.transform = transform
options.insertInto = undefined;

var update = __webpack_require__(/*! ../../../node_modules/style-loader/lib/addStyles.js */ "./node_modules/style-loader/lib/addStyles.js")(content, options);

if(content.locals) module.exports = content.locals;

if(false) {}

/***/ }),

/***/ "./node_modules/vue-h-zoom/dist/vue-h-zoom.js":
/*!****************************************************!*\
  !*** ./node_modules/vue-h-zoom/dist/vue-h-zoom.js ***!
  \****************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

!function(t,e){ true?module.exports=e():undefined}(this,function(){return function(t){function e(n){if(o[n])return o[n].exports;var i=o[n]={i:n,l:!1,exports:{}};return t[n].call(i.exports,i,i.exports,e),i.l=!0,i.exports}var o={};return e.m=t,e.c=o,e.i=function(t){return t},e.d=function(t,o,n){e.o(t,o)||Object.defineProperty(t,o,{configurable:!1,enumerable:!0,get:n})},e.n=function(t){var o=t&&t.__esModule?function(){return t.default}:function(){return t};return e.d(o,"a",o),o},e.o=function(t,e){return Object.prototype.hasOwnProperty.call(t,e)},e.p="",e(e.s=6)}([function(t,e,o){"use strict";Object.defineProperty(e,"__esModule",{value:!0}),e.default={name:"vue-h-zoom",props:{image:{type:String,required:!0},imageFull:{type:String,default:""},width:{type:Number,default:200},height:{type:Number,default:200},zoomLevel:{type:Number,default:4},zoomWindowSize:{type:Number,default:2},zoomWindowX:{type:Number,default:300},zoomWindowY:{type:Number,default:10}},data:function(){return{visibleZoom:!1,pointer:{x:0,y:0},thumbnailPos:{}}},methods:{toPx:function(t){return t+"px"},mouseEnter:function(){this.updateThumbnailPos(),this.visibleZoom=!0},mouseLeave:function(){this.visibleZoom=!1},followMouse:function(t){this.pointer={x:t.pageX-this.$refs.thumbnail.getBoundingClientRect().left-window.scrollX,y:t.pageY-this.$refs.thumbnail.getBoundingClientRect().top-window.scrollY}},updateThumbnailPos:function(){var t=this.$refs.thumbnail;this.thumbnailPos={top:t.offsetTop,left:t.offsetLeft}}},computed:{zoomWidth:function(){return this.zoomWindowSize*this.width},zoomHeight:function(){return this.zoomWindowSize*this.height},thumbnailStyle:function(){return{"background-image":"url("+this.image+")","background-size":"cover",height:this.toPx(this.height),width:this.toPx(this.width)}},containerStyle:function(){return{height:this.toPx(this.zoomHeight),width:this.toPx(this.zoomWidth),left:this.toPx(this.zoomWindowX),top:this.toPx(this.zoomWindowY),position:"absolute",overflow:"hidden",border:"1px solid #ccc"}},zoomPosX:function(){var t=this.width/2,e=-(this.pointer.x-this.thumbnailPos.left-t)*this.zoomWindowSize;return e>this.pointerEdgeX?this.pointerEdgeX:e<-1*this.pointerEdgeX?-1*this.pointerEdgeX:e},zoomPosY:function(){var t=this.height/2,e=-(this.pointer.y-this.thumbnailPos.top-t)*this.zoomWindowSize;return e>this.pointerEdgeY?this.pointerEdgeY:e<-1*this.pointerEdgeY?-1*this.pointerEdgeY:e},zoomStyle:function(){return{"background-image":"url("+this.largeImage+")","background-repeat":"no-repeat","background-position":this.toPx(this.zoomPosX)+" "+this.toPx(this.zoomPosY),"background-size":"cover",width:"100%",height:"100%","-webkit-transform":"scale("+this.zoomLevel+")",transform:"scale("+this.zoomLevel+")"}},pointerWidth:function(){return this.width/this.zoomLevel},pointerHeight:function(){return this.height/this.zoomLevel},pointerOffsetTop:function(){var t=this.pointer.y-this.pointerHeight/2-this.thumbnailPos.top;return t<0?0:t>this.height-this.pointerHeight?this.height-this.pointerHeight:t},pointerOffsetLeft:function(){var t=this.pointer.x-this.pointerWidth/2-this.thumbnailPos.left;return t<0?0:t>this.width-this.pointerWidth?this.width-this.pointerWidth:t},pointerEdgeX:function(){return(this.width-this.pointerWidth)*(this.zoomWindowSize/2)},pointerEdgeY:function(){return(this.height-this.pointerHeight)*(this.zoomWindowSize/2)},pointerBoxStyle:function(){return{position:"absolute","z-index":"999",transform:"translateZ(0px)",top:this.toPx(this.pointerOffsetTop),left:this.toPx(this.pointerOffsetLeft),width:this.toPx(this.pointerWidth),height:this.toPx(this.pointerHeight),background:"gray",opacity:.5,border:"1px solid white",cursor:"crosshair"}},largeImage:function(){return this.imageFull||this.image}}}},function(t,e){t.exports=function(t,e,o,n,i,r){var s,u=t=t||{},a=typeof t.default;"object"!==a&&"function"!==a||(s=t,u=t.default);var h="function"==typeof u?u.options:u;e&&(h.render=e.render,h.staticRenderFns=e.staticRenderFns,h._compiled=!0),o&&(h.functional=!0),i&&(h._scopeId=i);var d;if(r?(d=function(t){t=t||this.$vnode&&this.$vnode.ssrContext||this.parent&&this.parent.$vnode&&this.parent.$vnode.ssrContext,t||"undefined"==typeof __VUE_SSR_CONTEXT__||(t=__VUE_SSR_CONTEXT__),n&&n.call(this,t),t&&t._registeredComponents&&t._registeredComponents.add(r)},h._ssrRegister=d):n&&(d=n),d){var f=h.functional,l=f?h.render:h.beforeCreate;f?(h._injectStyles=d,h.render=function(t,e){return d.call(e),l(t,e)}):h.beforeCreate=l?[].concat(l,d):[d]}return{esModule:s,exports:u,options:h}}},function(t,e,o){"use strict";var n=function(){var t=this,e=t.$createElement,o=t._self._c||e;return o("div",{staticClass:"vue-h-zoom"},[o("div",{ref:"thumbnail",staticClass:"thumbnail-area",style:t.thumbnailStyle,on:{mouseenter:t.mouseEnter,mouseleave:t.mouseLeave,mousemove:function(e){if(e.target!==e.currentTarget)return null;t.followMouse(e)}}},[t.visibleZoom?o("div",{style:t.pointerBoxStyle,on:{mouseenter:t.mouseEnter,mousemove:function(e){if(e.target!==e.currentTarget)return null;t.followMouse(e)}}}):t._e()]),t._v(" "),t.visibleZoom?o("div",{staticClass:"img-zoom-container",style:t.containerStyle},[o("div",{style:t.zoomStyle})]):t._e()])},i=[];n._withStripped=!0;var r={render:n,staticRenderFns:i};e.a=r},function(t,e,o){var n=o(4);"string"==typeof n&&(n=[[t.i,n,""]]),n.locals&&(t.exports=n.locals);o(7)("7aca82c2",n,!1,{})},function(t,e,o){e=t.exports=o(5)(!1),e.push([t.i,"\n.thumbnail-area[data-v-cd0bf226] {\n  overflow: hidden;\n  position: relative;\n}\n.img-zoom-container[data-v-cd0bf226] {\n  -webkit-box-shadow: 5px 5px 5px 0px rgba(0,0,0,0.3);\n  -moz-box-shadow: 5px 5px 5px 0px rgba(0,0,0,0.3);\n  box-shadow: 5px 5px 5px 0px rgba(0,0,0,0.3);\n  z-index: 999;\n}\n",""])},function(t,e){function o(t,e){var o=t[1]||"",i=t[3];if(!i)return o;if(e&&"function"==typeof btoa){var r=n(i);return[o].concat(i.sources.map(function(t){return"/*# sourceURL="+i.sourceRoot+t+" */"})).concat([r]).join("\n")}return[o].join("\n")}function n(t){return"/*# sourceMappingURL=data:application/json;charset=utf-8;base64,"+btoa(unescape(encodeURIComponent(JSON.stringify(t))))+" */"}t.exports=function(t){var e=[];return e.toString=function(){return this.map(function(e){var n=o(e,t);return e[2]?"@media "+e[2]+"{"+n+"}":n}).join("")},e.i=function(t,o){"string"==typeof t&&(t=[[null,t,""]]);for(var n={},i=0;i<this.length;i++){var r=this[i][0];"number"==typeof r&&(n[r]=!0)}for(i=0;i<t.length;i++){var s=t[i];"number"==typeof s[0]&&n[s[0]]||(o&&!s[2]?s[2]=o:o&&(s[2]="("+s[2]+") and ("+o+")"),e.push(s))}},e}},function(t,e,o){"use strict";function n(t){a||o(3)}Object.defineProperty(e,"__esModule",{value:!0});var i=o(0),r=o.n(i);for(var s in i)["default","default"].indexOf(s)<0&&function(t){o.d(e,t,function(){return i[t]})}(s);var u=o(2),a=!1,h=o(1),d=n,f=h(r.a,u.a,!1,d,"data-v-cd0bf226",null);f.options.__file="src/libs/VueHZoom.vue",e.default=f.exports},function(t,e,o){function n(t){for(var e=0;e<t.length;e++){var o=t[e],n=d[o.id];if(n){n.refs++;for(var i=0;i<n.parts.length;i++)n.parts[i](o.parts[i]);for(;i<o.parts.length;i++)n.parts.push(r(o.parts[i]));n.parts.length>o.parts.length&&(n.parts.length=o.parts.length)}else{for(var s=[],i=0;i<o.parts.length;i++)s.push(r(o.parts[i]));d[o.id]={id:o.id,refs:1,parts:s}}}}function i(){var t=document.createElement("style");return t.type="text/css",f.appendChild(t),t}function r(t){var e,o,n=document.querySelector("style["+v+'~="'+t.id+'"]');if(n){if(p)return m;n.parentNode.removeChild(n)}if(b){var r=c++;n=l||(l=i()),e=s.bind(null,n,r,!1),o=s.bind(null,n,r,!0)}else n=i(),e=u.bind(null,n),o=function(){n.parentNode.removeChild(n)};return e(t),function(n){if(n){if(n.css===t.css&&n.media===t.media&&n.sourceMap===t.sourceMap)return;e(t=n)}else o()}}function s(t,e,o,n){var i=o?"":n.css;if(t.styleSheet)t.styleSheet.cssText=x(e,i);else{var r=document.createTextNode(i),s=t.childNodes;s[e]&&t.removeChild(s[e]),s.length?t.insertBefore(r,s[e]):t.appendChild(r)}}function u(t,e){var o=e.css,n=e.media,i=e.sourceMap;if(n&&t.setAttribute("media",n),g.ssrId&&t.setAttribute(v,e.id),i&&(o+="\n/*# sourceURL="+i.sources[0]+" */",o+="\n/*# sourceMappingURL=data:application/json;base64,"+btoa(unescape(encodeURIComponent(JSON.stringify(i))))+" */"),t.styleSheet)t.styleSheet.cssText=o;else{for(;t.firstChild;)t.removeChild(t.firstChild);t.appendChild(document.createTextNode(o))}}var a="undefined"!=typeof document;if("undefined"!=typeof DEBUG&&DEBUG&&!a)throw new Error("vue-style-loader cannot be used in a non-browser environment. Use { target: 'node' } in your Webpack config to indicate a server-rendering environment.");var h=o(8),d={},f=a&&(document.head||document.getElementsByTagName("head")[0]),l=null,c=0,p=!1,m=function(){},g=null,v="data-vue-ssr-id",b="undefined"!=typeof navigator&&/msie [6-9]\b/.test(navigator.userAgent.toLowerCase());t.exports=function(t,e,o,i){p=o,g=i||{};var r=h(t,e);return n(r),function(e){for(var o=[],i=0;i<r.length;i++){var s=r[i],u=d[s.id];u.refs--,o.push(u)}e?(r=h(t,e),n(r)):r=[];for(var i=0;i<o.length;i++){var u=o[i];if(0===u.refs){for(var a=0;a<u.parts.length;a++)u.parts[a]();delete d[u.id]}}}};var x=function(){var t=[];return function(e,o){return t[e]=o,t.filter(Boolean).join("\n")}}()},function(t,e){t.exports=function(t,e){for(var o=[],n={},i=0;i<e.length;i++){var r=e[i],s=r[0],u=r[1],a=r[2],h=r[3],d={id:t+":"+i,css:u,media:a,sourceMap:h};n[s]?n[s].parts.push(d):o.push(n[s]={id:s,parts:[d]})}return o}}])});

/***/ }),

/***/ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/components/Products.vue?vue&type=template&id=57b394cf&":
/*!***********************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/components/Products.vue?vue&type=template&id=57b394cf& ***!
  \***********************************************************************************************************************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "render", function() { return render; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return staticRenderFns; });
var render = function() {
  var _vm = this
  var _h = _vm.$createElement
  var _c = _vm._self._c || _h
  return _c(
    "div",
    { attrs: { id: "products" } },
    [
      _c(
        "v-container",
        {
          staticClass: "my-4",
          staticStyle: { "max-width": "1400px" },
          attrs: { fluid: "" }
        },
        [
          _c(
            "v-row",
            { attrs: { justify: "space-around" } },
            [
              !_vm.isMobile
                ? _c(
                    "v-col",
                    { attrs: { md: "3" } },
                    [
                      _c(
                        "v-card",
                        { attrs: { flat: "" } },
                        [
                          _c("v-card-title", [_vm._v("PRODUCTOS DESTACADOS")]),
                          _vm._v(" "),
                          false
                            ? undefined
                            : _c(
                                "v-row",
                                {
                                  staticClass: "ma-4",
                                  attrs: { justify: "space-around" }
                                },
                                [
                                  _c(
                                    "v-col",
                                    [
                                      _c("v-img", {
                                        attrs: {
                                          width: "50",
                                          height: "90",
                                          src:
                                            "https://cdn.vuetifyjs.com/images/cards/kitchen.png"
                                        }
                                      })
                                    ],
                                    1
                                  ),
                                  _vm._v(" "),
                                  _c(
                                    "v-col",
                                    [
                                      _c(
                                        "v-btn",
                                        {
                                          attrs: { text: "", color: "primary" }
                                        },
                                        [_vm._v(" SCREEN VX STUCCO")]
                                      )
                                    ],
                                    1
                                  )
                                ],
                                1
                              )
                        ],
                        1
                      ),
                      _vm._v(" "),
                      _c(
                        "v-card",
                        { attrs: { flat: "" } },
                        [
                          _c("v-card-title", [_vm._v("PRODUCTOS MÁS VISTOS")]),
                          _vm._v(" "),
                          false
                            ? undefined
                            : _c(
                                "v-row",
                                {
                                  staticClass: "ma-4",
                                  attrs: { justify: "space-around" }
                                },
                                [
                                  _c(
                                    "v-col",
                                    [
                                      _c("v-img", {
                                        attrs: {
                                          width: "50",
                                          height: "90",
                                          src:
                                            "https://cdn.vuetifyjs.com/images/cards/kitchen.png"
                                        }
                                      })
                                    ],
                                    1
                                  ),
                                  _vm._v(" "),
                                  _c(
                                    "v-col",
                                    [
                                      _c(
                                        "v-btn",
                                        {
                                          attrs: { text: "", color: "primary" }
                                        },
                                        [_vm._v(" SCREEN VX STUCCO")]
                                      )
                                    ],
                                    1
                                  )
                                ],
                                1
                              )
                        ],
                        1
                      ),
                      _vm._v(" "),
                      _c(
                        "v-card",
                        { attrs: { flat: "" } },
                        [
                          _c("v-card-title", [_vm._v("INFORMACIÓN ADICIONAL")]),
                          _vm._v(" "),
                          _c("v-card-text", { attrs: { color: "yellow" } }, [
                            _vm._v(
                              "\n                  Transformer theme is an elegant, powerful and fully responsive\n                  prestashop theme with modern design. Suitable for every type of store.\n                  This is a custom block edited from admin panel.You can insert any content here.\n                  Any orders placed through this store will not be honored or fulfilled\n                  "
                            )
                          ])
                        ],
                        1
                      )
                    ],
                    1
                  )
                : _vm._e(),
              _vm._v(" "),
              _c(
                "v-col",
                { attrs: { cols: "12", md: "9", sm: "12" } },
                [
                  _c("h1", { staticClass: "ma-4" }, [
                    _vm._v(_vm._s(_vm.productName))
                  ]),
                  _vm._v(" "),
                  _c("v-data-iterator", {
                    attrs: {
                      items: _vm.products,
                      "items-per-page": _vm.itemsPerPage,
                      page: _vm.page,
                      search: _vm.search,
                      "sort-by": _vm.sortBy,
                      "sort-desc": _vm.sortDesc,
                      "hide-default-footer": ""
                    },
                    scopedSlots: _vm._u([
                      {
                        key: "header",
                        fn: function() {
                          return [
                            _c(
                              "v-toolbar",
                              { staticClass: "mb-1", attrs: { flat: "" } },
                              [
                                [
                                  _c("v-select", {
                                    attrs: {
                                      color: "black",
                                      flat: "",
                                      "hide-details": "",
                                      items: _vm.keys,
                                      label: "Ordenar por"
                                    },
                                    model: {
                                      value: _vm.sortBy,
                                      callback: function($$v) {
                                        _vm.sortBy = $$v
                                      },
                                      expression: "sortBy"
                                    }
                                  }),
                                  _vm._v(" "),
                                  _c("v-spacer")
                                ]
                              ],
                              2
                            ),
                            _vm._v(" "),
                            _c("v-divider")
                          ]
                        },
                        proxy: true
                      },
                      {
                        key: "default",
                        fn: function(props) {
                          return [
                            _c(
                              "v-row",
                              _vm._l(props.items, function(item) {
                                return _c(
                                  "v-col",
                                  {
                                    key: item.name,
                                    attrs: {
                                      cols: "12",
                                      sm: "6",
                                      md: "4",
                                      lg: "3"
                                    }
                                  },
                                  [
                                    _c("v-hover", {
                                      scopedSlots: _vm._u(
                                        [
                                          {
                                            key: "default",
                                            fn: function(ref) {
                                              var hover = ref.hover
                                              return [
                                                _c(
                                                  "v-card",
                                                  {
                                                    staticClass: "mx-auto",
                                                    attrs: {
                                                      "max-width": "240",
                                                      height: "340",
                                                      color: "grey lighten-4",
                                                      flat: ""
                                                    }
                                                  },
                                                  [
                                                    _c(
                                                      "v-img",
                                                      {
                                                        staticClass:
                                                          "white--text align-end",
                                                        class: {
                                                          escalada: hover
                                                        },
                                                        attrs: {
                                                          width: "240",
                                                          height: "270",
                                                          "aspect-ratio":
                                                            16 / 9,
                                                          src: item.image,
                                                          gradient: hover
                                                            ? "rgba(71, 165, 173, 0.7) 100%, transparent 72px"
                                                            : ""
                                                        }
                                                      },
                                                      [
                                                        _c(
                                                          "v-slide-y-reverse-transition",
                                                          [
                                                            !hover
                                                              ? _c(
                                                                  "v-card-title",
                                                                  {
                                                                    staticClass:
                                                                      "title d-flex transition-fast-in-fast-out"
                                                                  },
                                                                  [
                                                                    _c(
                                                                      "b",
                                                                      {
                                                                        staticClass:
                                                                          "text-center"
                                                                      },
                                                                      [
                                                                        _vm._v(
                                                                          _vm._s(
                                                                            item.name
                                                                          )
                                                                        )
                                                                      ]
                                                                    )
                                                                  ]
                                                                )
                                                              : _vm._e()
                                                          ],
                                                          1
                                                        ),
                                                        _vm._v(" "),
                                                        _c(
                                                          "v-slide-x-transition",
                                                          [
                                                            hover
                                                              ? _c(
                                                                  "div",
                                                                  {
                                                                    staticClass:
                                                                      "d-flex transition-fast-in-fast-out  v-card--reveal white--text",
                                                                    staticStyle: {
                                                                      height:
                                                                        "100%"
                                                                    }
                                                                  },
                                                                  [
                                                                    _c(
                                                                      "v-hover",
                                                                      {
                                                                        scopedSlots: _vm._u(
                                                                          [
                                                                            {
                                                                              key:
                                                                                "default",
                                                                              fn: function(
                                                                                ref
                                                                              ) {
                                                                                var hover =
                                                                                  ref.hover
                                                                                return [
                                                                                  _c(
                                                                                    "v-btn",
                                                                                    {
                                                                                      attrs: {
                                                                                        to:
                                                                                          "/details/type/" +
                                                                                          _vm.productId +
                                                                                          "/product/" +
                                                                                          item.id,
                                                                                        depressed:
                                                                                          "",
                                                                                        outlined: !hover,
                                                                                        tile:
                                                                                          "",
                                                                                        color:
                                                                                          "white",
                                                                                        small:
                                                                                          ""
                                                                                      }
                                                                                    },
                                                                                    [
                                                                                      _vm._v(
                                                                                        "Detalles del producto"
                                                                                      )
                                                                                    ]
                                                                                  )
                                                                                ]
                                                                              }
                                                                            }
                                                                          ],
                                                                          null,
                                                                          true
                                                                        )
                                                                      }
                                                                    )
                                                                  ],
                                                                  1
                                                                )
                                                              : _vm._e()
                                                          ]
                                                        ),
                                                        _vm._v(" "),
                                                        _c(
                                                          "v-expand-transition",
                                                          [
                                                            hover
                                                              ? _c(
                                                                  "div",
                                                                  {
                                                                    staticClass:
                                                                      "d-flex transition-fast-in-fast-out  v-card--reveal white--text",
                                                                    staticStyle: {
                                                                      height:
                                                                        "20%"
                                                                    }
                                                                  },
                                                                  [
                                                                    _c(
                                                                      "v-hover",
                                                                      {
                                                                        scopedSlots: _vm._u(
                                                                          [
                                                                            {
                                                                              key:
                                                                                "default",
                                                                              fn: function(
                                                                                ref
                                                                              ) {
                                                                                var hover =
                                                                                  ref.hover
                                                                                return [
                                                                                  _c(
                                                                                    "v-btn",
                                                                                    {
                                                                                      attrs: {
                                                                                        depressed:
                                                                                          "",
                                                                                        outlined: !hover,
                                                                                        tile:
                                                                                          "",
                                                                                        color:
                                                                                          "white",
                                                                                        small:
                                                                                          ""
                                                                                      },
                                                                                      on: {
                                                                                        click: function(
                                                                                          $event
                                                                                        ) {
                                                                                          return _vm.openDialog(
                                                                                            item.id
                                                                                          )
                                                                                        }
                                                                                      }
                                                                                    },
                                                                                    [
                                                                                      _c(
                                                                                        "v-icon",
                                                                                        [
                                                                                          _vm._v(
                                                                                            "mdi-arrow-expand"
                                                                                          )
                                                                                        ]
                                                                                      )
                                                                                    ],
                                                                                    1
                                                                                  )
                                                                                ]
                                                                              }
                                                                            }
                                                                          ],
                                                                          null,
                                                                          true
                                                                        )
                                                                      }
                                                                    )
                                                                  ],
                                                                  1
                                                                )
                                                              : _vm._e()
                                                          ]
                                                        )
                                                      ],
                                                      1
                                                    ),
                                                    _vm._v(" "),
                                                    _c(
                                                      "v-card-text",
                                                      {
                                                        staticStyle: {
                                                          position: "relative"
                                                        }
                                                      },
                                                      [
                                                        _c(
                                                          "h2",
                                                          {
                                                            staticClass:
                                                              " font-weight-light black--text text-center"
                                                          },
                                                          [
                                                            _vm._v(
                                                              "\n                         $" +
                                                                _vm._s(
                                                                  item.price
                                                                ) +
                                                                "\n                        "
                                                            )
                                                          ]
                                                        )
                                                      ]
                                                    )
                                                  ],
                                                  1
                                                )
                                              ]
                                            }
                                          }
                                        ],
                                        null,
                                        true
                                      )
                                    })
                                  ],
                                  1
                                )
                              }),
                              1
                            ),
                            _vm._v(" "),
                            _c("v-divider")
                          ]
                        }
                      },
                      {
                        key: "footer",
                        fn: function() {
                          return [
                            _c(
                              "v-row",
                              {
                                staticClass: "mt-2",
                                attrs: { align: "center", justify: "center" }
                              },
                              [
                                _c("v-spacer"),
                                _vm._v(" "),
                                _c("span", { staticClass: "mr-4 grey--text" }, [
                                  _vm._v(
                                    " Página " +
                                      _vm._s(_vm.page) +
                                      " de " +
                                      _vm._s(_vm.numberOfPages)
                                  )
                                ]),
                                _vm._v(" "),
                                _c(
                                  "v-btn",
                                  {
                                    staticClass: "mr-1",
                                    attrs: {
                                      fab: "",
                                      dark: "",
                                      depressed: "",
                                      color: "white"
                                    },
                                    on: {
                                      click: function($event) {
                                        return _vm.formerPage()
                                      }
                                    }
                                  },
                                  [
                                    _c(
                                      "v-icon",
                                      { attrs: { color: "black" } },
                                      [_vm._v("mdi-chevron-left")]
                                    )
                                  ],
                                  1
                                ),
                                _vm._v(" "),
                                _c(
                                  "v-btn",
                                  {
                                    staticClass: "mr-1",
                                    attrs: {
                                      depressed: "",
                                      fab: "",
                                      dark: "",
                                      color: "white"
                                    },
                                    on: {
                                      click: function($event) {
                                        return _vm.nextPage()
                                      }
                                    }
                                  },
                                  [
                                    _c(
                                      "v-icon",
                                      { attrs: { color: "black" } },
                                      [_vm._v("mdi-chevron-right")]
                                    )
                                  ],
                                  1
                                )
                              ],
                              1
                            )
                          ]
                        },
                        proxy: true
                      }
                    ])
                  })
                ],
                1
              )
            ],
            1
          ),
          _vm._v(" "),
          _c(
            "v-dialog",
            {
              attrs: { width: "700px" },
              model: {
                value: _vm.dialog,
                callback: function($$v) {
                  _vm.dialog = $$v
                },
                expression: "dialog"
              }
            },
            [
              _c(
                "v-card",
                { attrs: { width: "700px", height: "500px" } },
                [
                  _c(
                    "v-row",
                    { attrs: { justify: "space-around" } },
                    [
                      _c(
                        "v-col",
                        { attrs: { cols: "12", md: "6", sm: "12" } },
                        [
                          _c("vue-h-zoom", {
                            attrs: {
                              width: 350,
                              height: 475,
                              image: _vm.products[_vm.selectedIndex - 1].image,
                              "zoom-level": 2,
                              "zoom-window-size": 1
                            }
                          })
                        ],
                        1
                      ),
                      _vm._v(" "),
                      _c(
                        "v-col",
                        { attrs: { cols: "12", md: "6", sm: "12" } },
                        [
                          _c(
                            "v-card-title",
                            [
                              _c("span", [
                                _vm._v(
                                  " " +
                                    _vm._s(
                                      _vm.products[_vm.selectedIndex - 1].name
                                    ) +
                                    " "
                                )
                              ]),
                              _vm._v(" "),
                              _c("v-spacer"),
                              _vm._v(" "),
                              _c(
                                "v-tooltip",
                                {
                                  attrs: { top: "" },
                                  scopedSlots: _vm._u([
                                    {
                                      key: "activator",
                                      fn: function(ref) {
                                        var on = ref.on
                                        var attrs = ref.attrs
                                        return [
                                          _c(
                                            "v-btn",
                                            _vm._g(
                                              _vm._b(
                                                {
                                                  attrs: { icon: "" },
                                                  on: {
                                                    click: function($event) {
                                                      _vm.dialog = false
                                                    }
                                                  }
                                                },
                                                "v-btn",
                                                attrs,
                                                false
                                              ),
                                              on
                                            ),
                                            [
                                              _c("v-icon", [
                                                _vm._v("mdi-close-thick")
                                              ])
                                            ],
                                            1
                                          )
                                        ]
                                      }
                                    }
                                  ])
                                },
                                [_vm._v(" "), _c("span", [_vm._v("Cerrar")])]
                              )
                            ],
                            1
                          ),
                          _vm._v(" "),
                          _c("v-card-subtitle", { staticClass: "display-2" }, [
                            _c("p", { staticStyle: { color: "#47a5ad" } }, [
                              _vm._v(
                                "$ " +
                                  _vm._s(
                                    _vm.products[_vm.selectedIndex - 1].price
                                  )
                              )
                            ])
                          ]),
                          _vm._v(" "),
                          _c(
                            "v-card-text",
                            [
                              true
                                ? _c(
                                    "v-list-item",
                                    [
                                      _c(
                                        "v-list-item-icon",
                                        [
                                          _c(
                                            "v-icon",
                                            { attrs: { color: "#47a5ad" } },
                                            [_vm._v("mdi-clipboard-check")]
                                          )
                                        ],
                                        1
                                      ),
                                      _vm._v(" "),
                                      _c(
                                        "v-list-item-title",
                                        { staticStyle: { color: "#47a5ad" } },
                                        [_vm._v("En Stock")]
                                      )
                                    ],
                                    1
                                  )
                                : undefined
                            ],
                            1
                          ),
                          _vm._v(" "),
                          _c("div", { attrs: { id: "box2" } })
                        ],
                        1
                      )
                    ],
                    1
                  )
                ],
                1
              )
            ],
            1
          )
        ],
        1
      )
    ],
    1
  )
}
var staticRenderFns = []
render._withStripped = true



/***/ }),

/***/ "./resources/js/components/Products.vue":
/*!**********************************************!*\
  !*** ./resources/js/components/Products.vue ***!
  \**********************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _Products_vue_vue_type_template_id_57b394cf___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./Products.vue?vue&type=template&id=57b394cf& */ "./resources/js/components/Products.vue?vue&type=template&id=57b394cf&");
/* harmony import */ var _Products_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./Products.vue?vue&type=script&lang=js& */ "./resources/js/components/Products.vue?vue&type=script&lang=js&");
/* empty/unused harmony star reexport *//* harmony import */ var _Products_vue_vue_type_style_index_0_lang_css___WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./Products.vue?vue&type=style&index=0&lang=css& */ "./resources/js/components/Products.vue?vue&type=style&index=0&lang=css&");
/* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");






/* normalize component */

var component = Object(_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_3__["default"])(
  _Products_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__["default"],
  _Products_vue_vue_type_template_id_57b394cf___WEBPACK_IMPORTED_MODULE_0__["render"],
  _Products_vue_vue_type_template_id_57b394cf___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"],
  false,
  null,
  null,
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "resources/js/components/Products.vue"
/* harmony default export */ __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ "./resources/js/components/Products.vue?vue&type=script&lang=js&":
/*!***********************************************************************!*\
  !*** ./resources/js/components/Products.vue?vue&type=script&lang=js& ***!
  \***********************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_babel_loader_lib_index_js_ref_4_0_node_modules_vue_loader_lib_index_js_vue_loader_options_Products_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../node_modules/babel-loader/lib??ref--4-0!../../../node_modules/vue-loader/lib??vue-loader-options!./Products.vue?vue&type=script&lang=js& */ "./node_modules/babel-loader/lib/index.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/components/Products.vue?vue&type=script&lang=js&");
/* empty/unused harmony star reexport */ /* harmony default export */ __webpack_exports__["default"] = (_node_modules_babel_loader_lib_index_js_ref_4_0_node_modules_vue_loader_lib_index_js_vue_loader_options_Products_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./resources/js/components/Products.vue?vue&type=style&index=0&lang=css&":
/*!*******************************************************************************!*\
  !*** ./resources/js/components/Products.vue?vue&type=style&index=0&lang=css& ***!
  \*******************************************************************************/
/*! no static exports found */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_style_loader_index_js_node_modules_css_loader_index_js_ref_6_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_6_2_node_modules_vue_loader_lib_index_js_vue_loader_options_Products_vue_vue_type_style_index_0_lang_css___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../node_modules/style-loader!../../../node_modules/css-loader??ref--6-1!../../../node_modules/vue-loader/lib/loaders/stylePostLoader.js!../../../node_modules/postcss-loader/src??ref--6-2!../../../node_modules/vue-loader/lib??vue-loader-options!./Products.vue?vue&type=style&index=0&lang=css& */ "./node_modules/style-loader/index.js!./node_modules/css-loader/index.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/components/Products.vue?vue&type=style&index=0&lang=css&");
/* harmony import */ var _node_modules_style_loader_index_js_node_modules_css_loader_index_js_ref_6_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_6_2_node_modules_vue_loader_lib_index_js_vue_loader_options_Products_vue_vue_type_style_index_0_lang_css___WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_style_loader_index_js_node_modules_css_loader_index_js_ref_6_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_6_2_node_modules_vue_loader_lib_index_js_vue_loader_options_Products_vue_vue_type_style_index_0_lang_css___WEBPACK_IMPORTED_MODULE_0__);
/* harmony reexport (unknown) */ for(var __WEBPACK_IMPORT_KEY__ in _node_modules_style_loader_index_js_node_modules_css_loader_index_js_ref_6_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_6_2_node_modules_vue_loader_lib_index_js_vue_loader_options_Products_vue_vue_type_style_index_0_lang_css___WEBPACK_IMPORTED_MODULE_0__) if(["default"].indexOf(__WEBPACK_IMPORT_KEY__) < 0) (function(key) { __webpack_require__.d(__webpack_exports__, key, function() { return _node_modules_style_loader_index_js_node_modules_css_loader_index_js_ref_6_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_6_2_node_modules_vue_loader_lib_index_js_vue_loader_options_Products_vue_vue_type_style_index_0_lang_css___WEBPACK_IMPORTED_MODULE_0__[key]; }) }(__WEBPACK_IMPORT_KEY__));
 /* harmony default export */ __webpack_exports__["default"] = (_node_modules_style_loader_index_js_node_modules_css_loader_index_js_ref_6_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_6_2_node_modules_vue_loader_lib_index_js_vue_loader_options_Products_vue_vue_type_style_index_0_lang_css___WEBPACK_IMPORTED_MODULE_0___default.a); 

/***/ }),

/***/ "./resources/js/components/Products.vue?vue&type=template&id=57b394cf&":
/*!*****************************************************************************!*\
  !*** ./resources/js/components/Products.vue?vue&type=template&id=57b394cf& ***!
  \*****************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_Products_vue_vue_type_template_id_57b394cf___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!../../../node_modules/vue-loader/lib??vue-loader-options!./Products.vue?vue&type=template&id=57b394cf& */ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/components/Products.vue?vue&type=template&id=57b394cf&");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "render", function() { return _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_Products_vue_vue_type_template_id_57b394cf___WEBPACK_IMPORTED_MODULE_0__["render"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_Products_vue_vue_type_template_id_57b394cf___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"]; });



/***/ })

}]);